#Import libraries
import pandas as pd
import numpy as np
from scipy.interpolate import interp1d
import os
import matplotlib.pyplot as plt

def process_decay_data(baseline_file, new_file):

    baseCurve = pd.read_csv(baseline_file)    
    baseCurve['Voltage'] = baseCurve['Voltage'].replace(0, 0.01)

    newCurve = pd.read_csv(new_file)
    newCurve['Voltage'] = newCurve['Voltage'].replace(0, 0.01)

    baseCurve['Vinv'] = 1 / baseCurve['Voltage']
    newCurve['Vinv'] = 1 / newCurve['Voltage']

    #Interpolate data
    f1 = interp1d(newCurve['Voltage'], newCurve['Time'], kind = 'linear', fill_value='extrapolate')
    f2 = interp1d(baseCurve['Voltage'], newCurve['Time'], kind = 'linear', fill_value='extrapolate')

    #Interpolate inverse data
    f1Inv = interp1d(newCurve['Vinv'], newCurve['Time'], kind = 'linear', fill_value='extrapolate')
    f2Inv = interp1d(baseCurve['Vinv'], newCurve['Time'], kind = 'linear', fill_value='extrapolate')
    
    #Find common voltages
    commonVolts = np.linspace(
        min(newCurve['Voltage'].min(), baseCurve['Voltage'].min()),
        max(newCurve['Voltage'].max(), baseCurve['Voltage'].max()),
        500
    )

    #find common inverse voltages
    commonVoltsInv = np.linspace(
        min(newCurve['Vinv'].min(), baseCurve['Vinv'].min()), 
        max(newCurve['Vinv'].max(), baseCurve['Vinv'].max()),
        500
    )

    interpolatedTime1 = f1(commonVolts)
    interpolatedTime2 = f2(commonVolts)

    interpolatedInvTime1 = f1Inv(commonVoltsInv)
    interpolatedInvTime2 = f2Inv(commonVoltsInv)

    timeDifference = interpolatedTime2 - interpolatedTime1
    timeDifferenceInv = interpolatedInvTime2 - interpolatedInvTime1

    plt.plot(timeDifferenceInv, commonVoltsInv, label= 'Interpolated Time Difference Between Voltage Values')
    plt.xlabel('Time Difference (uS)')
    plt.ylabel('Volts (V)')
    plt.show  

    #export the differences of the files to a .csv file
    differences_df = pd.DataFrame({
        "TimeDifferences": timeDifference,
        "Voltages":commonVolts
    })
    differences_df.to_csv('timeDifferences.csv')

    differences_df = pd.DataFrame({
        "TimeDifferencesInv": timeDifferenceInv,
        "VoltagesInv":commonVoltsInv
    })
    differences_df.to_csv('timeDifferencesInv.csv')

#Define the baseline file. The baseline will be the first reading
baseline_file = "data2(Good Cap).csv"

#Define the new file that just came in. Need to add code that switches this whenever a new file comes in.
new_file = "data1(Bad Cap).csv"

process_decay_data(baseline_file, new_file)
