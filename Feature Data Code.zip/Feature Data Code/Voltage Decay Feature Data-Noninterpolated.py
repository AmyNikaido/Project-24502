import numpy as np
import scipy as sp
import matplotlib.pyplot as plt
import pandas as pd
%matplotlib inline

def process_decay_data(baseline_file, new_file):
    
    baseCurve = pd.read_csv(baseline_file)    
    baseCurve['Voltage'] = baseCurve['Voltage'].replace(0, 0.01)

    newCurve = pd.read_csv(new_file)
    newCurve['Voltage'] = newCurve['Voltage'].replace(0, 0.01)

    baseCurve['Vinv'] = 1 / baseCurve['Voltage']
    newCurve['Vinv'] = 1 / newCurve['Voltage']

    mergedData = pd.merge(newCurve, baseCurve, on='Voltage',how='inner', suffixes=('_1', '_2'))
    mergedDataInv = pd.merge(newCurve, baseCurve, on='Vinv',how='inner', suffixes=('_1', '_2'))
    
    mergedData['timeDiff'] = mergedData['Time_2'] - mergedData['Time_1']
    mergedDataInv['timeDiffInv'] = mergedData['Time_2'] - mergedData['Time_1']

  #export the differences of the files to a .csv file
    differences_df = pd.DataFrame({
        "TimeDifferences": mergedData['timeDiff'],
        "Voltages":mergedData['Voltage']
    })
    differences_df.to_csv('timeDifferences.csv', index = False)

    differences_df = pd.DataFrame({
        "TimeDifferencesInv": mergedDataInv['timeDiffInv'],
        "VoltagesInv":mergedDataInv['Vinv']
    })
    differences_df.to_csv('timeDifferencesInv.csv', index=False)

#Define the baseline file. The baseline will be the first reading
baseline_file = "data2(Good Cap).csv"

#Define the new file that just came in. Need to add code that switches this whenever a new file comes in.
new_file = "data1(Bad Cap).csv"

process_decay_data(baseline_file, new_file)